"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/atob";
exports.ids = ["vendor-chunks/atob"];
exports.modules = {

/***/ "(ssr)/./node_modules/atob/node-atob.js":
/*!****************************************!*\
  !*** ./node_modules/atob/node-atob.js ***!
  \****************************************/
/***/ ((module) => {

eval("\n\nfunction atob(str) {\n  return Buffer.from(str, 'base64').toString('binary');\n}\n\nmodule.exports = atob.atob = atob;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvYXRvYi9ub2RlLWF0b2IuanMiLCJtYXBwaW5ncyI6IkFBQWE7O0FBRWI7QUFDQTtBQUNBOztBQUVBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dGpzLy4vbm9kZV9tb2R1bGVzL2F0b2Ivbm9kZS1hdG9iLmpzPzdjZGQiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5cbmZ1bmN0aW9uIGF0b2Ioc3RyKSB7XG4gIHJldHVybiBCdWZmZXIuZnJvbShzdHIsICdiYXNlNjQnKS50b1N0cmluZygnYmluYXJ5Jyk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gYXRvYi5hdG9iID0gYXRvYjtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/atob/node-atob.js\n");

/***/ })

};
;